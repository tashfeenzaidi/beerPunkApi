package com.punkapi.beerapp.service

class Service {
    companion object{
        const val BASE_URL:String = "https://api.punkapi.com/v2/"
    }
}
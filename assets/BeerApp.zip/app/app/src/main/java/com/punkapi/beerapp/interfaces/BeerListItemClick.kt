package com.punkapi.beerapp.interfaces

interface BeerListItemClick {
    fun onItemClick(index:Int)
}